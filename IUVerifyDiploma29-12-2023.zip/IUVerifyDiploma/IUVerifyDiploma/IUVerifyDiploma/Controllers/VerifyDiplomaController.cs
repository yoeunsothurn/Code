﻿using IUVerifyDiploma.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IUVerifyDiploma.Controllers
{
    public class VerifyDiplomaController : Controller
    {
        public IActionResult Index()
         {
            //add Session
            string UserName= HttpContext.Session.GetString("UserName");
            if (string.IsNullOrEmpty(UserName))
            {
                return RedirectToAction("Index", "UserLogin");
            }
     

            VerifyDiploma model = new VerifyDiploma();
            try
            {

                model.GetDataVerifyDiploma();
                return View(model);
            }
            catch(Exception ex)
            {
                ViewBag.error = ex.Message;
                return View(model);
            }
           
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Index(VerifyDiploma model)
        {
            try
            {
                model.GetDataVerifyDiploma();
                return View(model);
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View(model);
            }
        }
    }
}
