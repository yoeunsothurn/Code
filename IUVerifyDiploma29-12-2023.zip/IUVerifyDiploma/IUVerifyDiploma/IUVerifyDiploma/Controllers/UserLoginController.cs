﻿using IUVerifyDiploma.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace IUVerifyDiploma.Controllers
{
    public class UserLoginController : Controller
    {
        public IActionResult Index()
        {
           
            HttpContext.Session.SetString("UserName","");
            return View();
        }
        [HttpPost]

        public IActionResult Login(UserLogin model)
        {
           
            try
            {
                DataTable dt = new DataTable();
                model.Password = StaticService.Encrypts(model.Password);
                dt = model.UserLogins();
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[0]["UserName"].ToString() == model.UserName && dt.Rows[0]["Password"].ToString() == model.Password)
                    {
                        HttpContext.Session.SetString("UserName", model.UserName);
                        HttpContext.Session.SetString("IP", model.IP);
                        return RedirectToAction("Index", "VerifyDiploma");

                    }
                }
                ViewBag.InvaliveLogin = "Wrong username and password....!";
            }
            catch(Exception ex)
            {
                ViewBag.error = ex.Message;
            }
            return View("Index");
        }
        public IActionResult LogOut()
        {
             UserLogin model = new UserLogin();
             model.UserName = HttpContext.Session.GetString("UserName");
             model.IP= HttpContext.Session.GetString("IP");
             model.UserLogOut();

            return View("Index");
        }
    }
}
