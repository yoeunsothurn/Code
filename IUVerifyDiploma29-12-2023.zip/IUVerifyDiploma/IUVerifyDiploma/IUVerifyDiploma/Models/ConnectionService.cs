﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;


namespace IUVerifyDiploma.Models
{
    public class ConnectionService
    {
        private SqlCommand _Cmd = new SqlCommand();
        private string _ProcName = "";
        private SqlConnection _Conn;
        private Boolean _autoClose;
        private Boolean _isTransac = false;
        private SqlTransaction _transa;
        public string ProcName { set { _ProcName = value; } }
        public class parasql
        {
            public string paraname { get; set; }
            public SqlDbType sqltype { get; set; }
            public dynamic values { get; set; }

        }
        public void setParameter(List<parasql> para)
        {
            _Cmd.CommandText = _ProcName;
            _Cmd.Parameters.Clear();
            foreach (parasql tmp in para)
            {
                _Cmd.Parameters.Add(tmp.paraname, tmp.sqltype).Value = tmp.values;
            }
        }
        public bool AutoClose
        {
            set { _autoClose = value; }
        }
        public void openConn()
        {
            _Conn = new SqlConnection();
            _Conn.ConnectionString = ConString();
            _Conn.Open();
            if (_isTransac)
            {
                _transa = _Conn.BeginTransaction();
                _Cmd = _Conn.CreateCommand();
                _Cmd.CommandType = CommandType.StoredProcedure;
                _Cmd.CommandTimeout = 360000000;
                _Cmd.Connection = _Conn;
                _Cmd.Transaction = _transa;

            }
            else
            {
                _Cmd = _Conn.CreateCommand();
                _Cmd.CommandType = CommandType.StoredProcedure;
            }

        }
        private string ConString()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            return builder.Build().GetSection("ConnectionStrings").GetSection("Report").Value;
            //Data Source = 192.168.2.219; Initial Catalog = dbHR_System; User ID = sa; Password = 123@123
        }
        public void FillTable(DataTable dt)
        {
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = _Cmd;
            da.SelectCommand.CommandTimeout = 360000000;
            da.Fill(dt);
            if (_autoClose)
            {
                _Conn.Dispose();
                _Conn.Close();
            }
        }
        public void CommitTran()
        {
            if (_isTransac)
            {
                _transa.Commit();
            }
        }
        public void Rollback()
        {
            try
            {
                _transa.Rollback();
            }
            catch (Exception ex2)
            {
                // This catch block will handle any errors that may have occurred
                // on the server that would cause the rollback to fail, such as
                // a closed connection.
                Console.WriteLine("Rollback Exception Type: {0}", ex2.GetType());
                Console.WriteLine("  Message: {0}", ex2.Message);
            }
        }
    }
}
