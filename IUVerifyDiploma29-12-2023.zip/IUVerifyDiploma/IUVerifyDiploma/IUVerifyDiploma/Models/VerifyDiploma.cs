﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using static IUVerifyDiploma.Models.ConnectionService;

namespace IUVerifyDiploma.Models
{
    public class VerifyDiploma
    {
        public string ID { get; set; }
        public string No { get; set; }
        public string FullName { get; set; }
        public string InLatin { get; set; }
        public string Sex { get; set; }
        public string Dob { get; set; }
        public string Diploma { get; set; }
        public string Major { get; set; }
        public string Batch { get; set; }
        public string Status { get; set; }
        public string Graduation { get; set; }
        public DataTable DataVerifyDiploma { get; set; }
       // public string StudentId { get; set; }



        public void GetDataVerifyDiploma()
        {
            ConnectionService Conn = new ConnectionService();
            try
            {
                DataTable dt = new DataTable();
                Conn.AutoClose = true;
                Conn.openConn();
                List<parasql> db = new List<parasql>();
                db.Add(new parasql { paraname = "@pStudentID", sqltype = SqlDbType.NVarChar, values = ID });
                db.Add(new parasql { paraname = "@pDiploma", sqltype = SqlDbType.NVarChar, values = Diploma });
                db.Add(new parasql { paraname = "@pFullName", sqltype = SqlDbType.NVarChar, values = FullName });
                db.Add(new parasql { paraname = "@pInLatin", sqltype = SqlDbType.NVarChar, values = InLatin });
                db.Add(new parasql { paraname = "@pBatch", sqltype = SqlDbType.NVarChar, values = Batch });
                Conn.ProcName = "[Pro_GetDataVerifyDiploma]";
                Conn.setParameter(db);
                Conn.FillTable(dt);
                Conn.setParameter(db);
                Conn.CommitTran();
                this.DataVerifyDiploma = dt;

            }
            catch (Exception ex)
            {
                //Conn.Rollback();
                throw new Exception(ex.Message);
            }
        }
      
    }
}
//Sex DOB	ID	Dimploma	Major	Batch	Status	Graduation