﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using static IUVerifyDiploma.Models.ConnectionService;

namespace IUVerifyDiploma.Models
{
    public class UserLogin
    {
        [Required(ErrorMessage = "Please input Password")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Please input UserName")]
        public string UserName { get; set; }
        public string IP { set; get; }
        public string UserLog { set; get; }
        public string LogDate { set; get; }
        public string Statuslog { set; get; }

        public DataTable UserLogins()
        {
            ConnectionService Conn = new ConnectionService();
            try
            {
                UserLog = UserName;
                DataTable dt = new DataTable();
                Conn.AutoClose = true;
                Conn.openConn();//contodata base

                List<parasql> db = new List<parasql>();
                db.Add(new parasql { paraname = "@pPassword", sqltype = SqlDbType.NVarChar, values = this.Password });
                db.Add(new parasql { paraname = "@pUserId", sqltype = SqlDbType.NVarChar, values = this.UserName });
                db.Add(new parasql { paraname = "@pIP", sqltype = SqlDbType.NVarChar, values = this.IP });
                db.Add(new parasql { paraname = "@pUserLog", sqltype = SqlDbType.NVarChar, values = this.UserLog });
                db.Add(new parasql { paraname = "@pLogDate", sqltype = SqlDbType.NVarChar, values = this.LogDate });
                db.Add(new parasql { paraname = "@pStatuslog", sqltype = SqlDbType.NVarChar, values = this.Statuslog });
                Conn.ProcName = "ProUserLoginVerifyDiploma";
                Conn.setParameter(db);
                Conn.FillTable(dt);
                Conn.setParameter(db);
                Conn.CommitTran();


                return dt;
            }
            catch (Exception ex)
            {
                Conn.Rollback();
                throw new Exception(ex.Message);
            }
        }
        public DataTable UserLogOut()
        {
            ConnectionService Conn = new ConnectionService();
            try
            {
                UserLog = UserName;
                DataTable dt = new DataTable();
                Conn.AutoClose = true;
                Conn.openConn();//contodata base

                List<parasql> db = new List<parasql>();
                db.Add(new parasql { paraname = "@pPassword", sqltype = SqlDbType.NVarChar, values = this.Password });
                db.Add(new parasql { paraname = "@pUserId", sqltype = SqlDbType.NVarChar, values = this.UserName });
                db.Add(new parasql { paraname = "@pIP", sqltype = SqlDbType.NVarChar, values = this.IP });
                db.Add(new parasql { paraname = "@pUserLog", sqltype = SqlDbType.NVarChar, values = this.UserLog });
                db.Add(new parasql { paraname = "@pLogDate", sqltype = SqlDbType.NVarChar, values = this.LogDate });
                db.Add(new parasql { paraname = "@pStatuslog", sqltype = SqlDbType.NVarChar, values = this.Statuslog });
                Conn.ProcName = "ProUserLogOutVerifyDiploma";
                Conn.setParameter(db);
                Conn.FillTable(dt);
                Conn.setParameter(db);
                Conn.CommitTran();


                return dt;
            }
            catch (Exception ex)
            {
                Conn.Rollback();
                throw new Exception(ex.Message);
            }
        }
    }
}
